#Using Node

* Interact with Node Console (node)
* Run a file with node (node <filename>)

