#Intro to NPM

* Define NPM
* Explain why NPM is awesome
* Intro the packages we will end up using


#Installing and Using Packages

* Use `npm install` to install a package
* Use `require()` to include a package