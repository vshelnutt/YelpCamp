#SOMEWHAT FUN NPM EXERCISE (YAY)

* Create a new directory named "MyShop"
* Add a file named "listProducts.js"
* Install the "Faker" package
* Read the Faker docs and figure out how it works
* Use Faker to print out 10 random product names and prices
* BE RESOURCEFUL! DON'T CHEAT AND FAST FORWARD!!!
* Run your file with node and make sure it works!
